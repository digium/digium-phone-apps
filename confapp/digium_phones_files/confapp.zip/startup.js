// require all the necessary libary files
var app = require('app');
app.init();
var screen = require('screen');
var util = require('util');
var genericMenu = require('genericMenu');
var pbx = require('pbx');

confApp = {}

//initialize variables and set up display widgets
confApp.init = function () {
    util.debug("starting up");
    //cache the app's config settings with default values
    var config = app.getConfig();
	var handler = {};
    this.exten = config.settings.exten;
    this.user = config.account.username;

/*
    screen.clear();
    var showSetup = new Text(0, 0, window.w, Text.LINE_HEIGHT, 'Exten = ' + this.exten + ', user = ' + this.user);
    window.add(showSetup);
*/

	var selectCallback = function (selection) {
		util.debug("Selected " + selection);
	}

	
	// take the parameters from the AMI event
	// add users to the user list
	// update the onscreen menu
    var processParams = function (p) {
            //util.debug('Success! this is p:' + JSON.stringify(p));
			users = [];
			info = p.result;
			if (!info)
				info = p.eventData;
			if (info) {
				for (var k in info) {
	    				if (info.hasOwnProperty(k)) {
    						users.push({ text: info[k].calleridname + " (" + info[k].calleridnum + ")", id: info[k].calleridnum });
					}
				}
				util.debug("Userlist: " + JSON.stringify(users));
				globalMenu.menu = users; // add users to menu
				genericMenu.show(globalMenu); // update the onscreen menu
			}
	};


	// take key press events and 
	// send action to the server 
	handler.processMenuAction = function(params) {
		if (undefined == params.actionId)
			return;
		util.debug(params.actionId + " applied to " + params.selectionId);
		switch(params.actionId) {
		case 'kick':
		case 'mute':
		case 'unmute':
			pbx.request( {
				'method' : 'digium.confapp',
				'parameters' : { 'action' : params.actionId, 'cid' : params.selectionId },
				'onSuccess' : function (p) {
					util.debug("Success applying " + params.actionId + " to " + params.selectionId + ": " + JSON.stringify(p));
					processParams(p);
				},
				'onError' : function(p) {
					util.debug("Failure applying " + params.actionId + " to " + params.selectionId + ": " + JSON.stringify(p));
				},
			});
			break;
		case 'exit':
			digium.background();
			break;
		}
	};

	// register to the server when app is started
    pbx.request( {
        'method' : 'digium.confapp',
        'parameters' : {
            'action' : 'register',
                        'phonename' : confApp.user,
                        'cid' : confApp.exten,
        },
        'onSuccess' : function(p) {
		util.debug("Got request result: " + JSON.stringify(p));
		processParams(p);
		},
		'onError' : function(p) {
				util.debug('We got an Error houston - this is p:');
				util.debug(JSON.stringify(p));
		}
    });

	// create softkeys to use in globalMenu
	var softkeys = [
		{ label: "Kick", actionId: "kick" },
		{ label: "Mute", actionId: "mute" },
		{ label: "Unmute", actionId: "unmute" },
		{ label: "Exit", actionId: "exit" },
	]; 


	// array of objects to represent items in the menu
	// gets passed to genericMenu.show()	
	var globalMenu = {
		'id' : 'confApp_list',
		'menu' : [],
		'softkeys' : softkeys,
		'object' : handler, // pass object with processMenuAction() method
		'title'       : "Current Conference",
		'onkeyselect' : selectCallback,
		'onkeycancel' : digium.background,
		'forceRedraw' : true // TODO get malcolm to document this
	};

	// 
	digium.event.observe({
		'eventName' : 'digium.confapp.update',
		'callback' : function (params) {
			util.debug("Event: " + JSON.stringify(params));
			processParams(params);
		}
	});

	// show the menu when the app starts
	genericMenu.show(globalMenu);
};

//execute the init function immediately when this app is started
confApp.init();
